# -*- coding: utf-8 -*-
"""
Created on Sun Jul 26 12:48:59 2020

@author: Hrishikesh Shinde (214966)

"""
#included libraries
import pygame
import math
import pandas as pd
import random
import os
import matplotlib.pyplot as plt
import sys

#initializing pygame
pygame.init()

#creating window
screen = pygame.display.set_mode((800,600))

#Caption and Icon
pygame.display.set_caption("Balloon Hunt")
icon = pygame.image.load('balloon icon.png')
pygame.display.set_icon(icon)

#background_sound
pygame.mixer.music.load('background_music.mp3')
pygame.mixer.music.play(-1)

#background Image
background = pygame.image.load('background_image.jpg')
login_background = pygame.image.load('Login Page.jpg')
game_over_image = pygame.image.load('gameover.jpg')

#Player Entity
playerImg = pygame.image.load('player_icon.png')
playerX = 370
playerY = 450
playerX_change = 0

"""
#single enemy
enemyImg = pygame.Enemyimage.load('Single_Blue_Balloon_Image_icon.png')
enemyX = random.randint(0,710)
enemyY = random.randint(-400,0) 
enemyX_change = 0
enemyY_change = +2
"""


#Enemy Entity (Balloon)
enemyImg = []
enemyX = []
enemyY = []
enemyX_change = []
enemyY_change = [] 
number_of_balloon = 12
enemyImg.append(pygame.image.load('Single_Blue_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Yellow_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Purple_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Red_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Cyan_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Green_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Blue_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Yellow_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Purple_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Red_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Cyan_Balloon_Image_icon.png'))
enemyImg.append(pygame.image.load('Single_Green_Balloon_Image_icon.png'))
for i in range(number_of_balloon):
    enemyX.append(random.randint(0,710))
    enemyY.append(random.randint(-400,0))
    enemyX_change.append(0)
    enemyY_change.append(0.2)



#Sword
#ready- sword not visible
#fire - seen
"""
#single sword
swordImg = pygame.image.load('sword.png')
swordX = 0
swordY = 480
swordX_change = 0
swordY_change = 3
sword_state = "ready"
"""

#multiple Swords
swordImg = []
swordX = []
swordY = []
swordX_change = []
swordY_change = []
number_of_swords=7
sword_state = []

for i in range(number_of_swords):
    #fire - seen
    swordImg.append(pygame.image.load('sword.png'))
    swordX.append(0)
    swordY.append(450)
    swordX_change.append(0)
    swordY_change.append(5)
    sword_state.append("ready")

# to display player entity on pygame window
def player(x,y):
    screen.blit(playerImg,(x,y)) 

# to display player on py game window   
def enemy(x,y,i):
    screen.blit(enemyImg[i],(x,y)) 
    
# to launch/display the swords pygame window    
def launch_sword(x,y,num):
    global number_of_swords
    global sword_state
    sword_state[num]= "fire"
    #print(sword_state)
    for n in range (number_of_swords):
        #print(sword_state)
        #print(n)
        if sword_state[n]=="fire":
           # print (f"Sq no {num}")
           #print(swordY)
           screen.blit(swordImg[n],(x+16,y+10))

#to detect collision of sword and balloon
def isCollision(enemyX,enemyY,swordX,swordY):
    distance = math.sqrt(math.pow(enemyX-5-swordX,2)+math.pow(enemyY-swordY,2))
    if distance <50:
        return True
    else:
        return False
    

font = pygame.font.Font('freesansbold.ttf',32)
textX = 10
textY = 10
DtextX = 570
DtextY = 10

# to display score on pygame window while playing
def show_score(x,y):
    global score_value
    score = font.render("Score: "+str(score_value),True,(255,255,255))
    screen.blit(score,(x,y))

# to display damage on pygame window while playing
def show_damage(x,y):
    global damage_value
    damage = font.render("Damage: "+str(damage_value)+"%",True,(255,0,0))
    screen.blit(damage,(x,y)) 
    
score_value = 0
damage_value = 0

#game over
over_font = pygame.font.Font('freesansbold.ttf',45 )
prev_font = pygame.font.Font('freesansbold.ttf',25 )
csv_flag = True
leaderboard_font = pygame.font.Font('freesansbold.ttf',20)
def game_over():
    global csv_flag
    global player_data
    screen.blit(game_over_image,(0,0))
    graph = pygame.image.load('graph.jpg')
    screen.blit(graph,(450,120))
    if csv_flag:
        check_csv()
        update_csv()
        csv_flag = False
    display_leaderboard()
    
# displaying leaderboard on pygame window    
def display_leaderboard():
    global score_value
    global player_data
    prev_score = prev_font.render(str(player_data['Score'][return_rank()-1]),True,(255,255,255))
    screen.blit(prev_score,(325,240))
    
    score = over_font.render(str(score_value),True,(255,255,255))
    screen.blit(score,(240,140))
    #print(player_data.dtypes)
    rank = over_font.render(str(return_rank()),True,(255,255,255))
    screen.blit(rank,(240,190))
    leaderboard_title = leaderboard_font.render(str('ID'),True,(255,128,0))
    screen.blit(leaderboard_title,(250,350))
    leaderboard_title = leaderboard_font.render(str('Rank'),True,(255,0,127))
    screen.blit(leaderboard_title,(400,350))
    leaderboard_title = leaderboard_font.render(str('Name'),True,(255,255,0))
    screen.blit(leaderboard_title,(500,350))
    leaderboard_title = leaderboard_font.render(str('Score'),True,(0,255,0))
    screen.blit(leaderboard_title,(700,350))
    
    #screen.blit(playerImg,(x,y))
    x=player_data['Rank'].count()
    if x<5:
        x=x=player_data['Rank'].count()
    else:
        x = 5
        
    for i in range(x):
        
        leaderboard = leaderboard_font.render(str(player_data['ID'][i]),True,(255,128,0))
        screen.blit(leaderboard,(250,390+i*40))
        
        leaderboard = leaderboard_font.render(str(player_data['Rank'][i]),True,(255,0,127))
        screen.blit(leaderboard,(400,390+i*40))
        
        leaderboard = leaderboard_font.render(str(player_data['Name'][i]),True,(255,255,0))
        screen.blit(leaderboard,(500,390+i*40))
        
        leaderboard = leaderboard_font.render(str(player_data['Score'][i]),True,(0,255,0))
        screen.blit(leaderboard,(700,390+i*40))
      
#function returns rank of the player
def return_rank():
    global player_data
    global text
    #print()
    
    rank_counter = 0
    for n in player_data['ID']:
        rank_counter +=1
        if str(n)==str(text):
            #print(rank_counter)
            return  rank_counter
    

input_font = pygame.font.Font('freesansbold.ttf',64 )
text = ''
name_text=''
# fuction to take input from pygame windows text box and store the inputs
def user_input():
    screen.blit(login_background,(0,0))
    input_box = pygame.Rect(350, 435, 140, 35)
    input_box1 = pygame.Rect(350, 480, 140, 35)
    button = pygame.Rect(580, 445, 100, 60)
    color_inactive = pygame.Color(0,0,0)
    color_active = pygame.Color(255,0,0)
    color = color_inactive
    color1 = color_inactive
    color2 = color_inactive
    active = False
    active1 = False
    active2 = False
    global text
    global name_text
    done = False

    while not done:
        for event in pygame.event.get():
            #to check any enent has happend or not
            if event.type == pygame.QUIT:
                    pygame.display.quit()
                    pygame.quit()
                    sys.exit()
            #mouse button down event
            if event.type == pygame.MOUSEBUTTONDOWN:
                # If the user clicked on the input_box rect.
                if input_box.collidepoint(event.pos):
                    # Toggle the active variable.
                    active = not active
                else:
                    active = False
                    
                if input_box1.collidepoint(event.pos):
                    active1 = not active1
                else:
                    active1 = False
                if event.button == 1:
                    # `event.pos` is the mouse position.
                    if button.collidepoint(event.pos):
                        # Increment the number.
                        active2 = not active2
                        done = True
                    else:
                        active2 = False
                # Change the current color of the input box.
                color = color_active if active else color_inactive
                color1 = color_active if active1 else color_inactive
                color2 = color_inactive if active2 else pygame.Color(255,0,0)
            
            #for user input data
            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        done = True
                        return text
                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                        screen.blit(login_background,(0,0))
                        input_box = pygame.Rect(350, 435, 140, 35)
                    else:
                        text += event.unicode
                if active1:
                    if event.key == pygame.K_RETURN:
                        done = True
                        return name_text
                    elif event.key == pygame.K_BACKSPACE:
                        name_text = name_text[:-1]
                        screen.blit(login_background,(0,0))
                        input_box1 = pygame.Rect(350, 480, 140, 35)
                    else:
                        name_text += event.unicode
        #to display start button
        pygame.draw.rect(screen, color2, button)
        start_font = pygame.font.Font('freesansbold.ttf',25 )
        text_surf = start_font.render('START', True, (255,255,255))
        # You can pass the center directly to the `get_rect` method.
        text_rect = text_surf.get_rect(center=(630, 477))
        screen.blit(text_surf, text_rect)
        
        
        # Render the current text.
 
        txt_surface = font.render(text, True, color)
        txt_surface1 = font.render(name_text, True, color1)
        # Resize the box if the text is too long.
        width = max(200, txt_surface.get_width()+10)
        width1 = max(200, txt_surface1.get_width()+10)
        input_box.w = width
        input_box1.w = width1
        # Blit the text.
        screen.blit(txt_surface, (input_box.x+5, input_box.y+5))
        screen.blit(txt_surface1, (input_box1.x+5, input_box1.y+5))
        # Blit the input_box rect.
        pygame.draw.rect(screen, color, input_box, 2)
        pygame.draw.rect(screen, color1, input_box1, 2)
        #print(text)
        #print(name_text)
        pygame.display.flip()
        
player_data = pd.DataFrame(columns = ['Rank','ID','Name','Score','Date'],index=None)
# to check whether csv file exists or not
# if exists: then read csv file
# if dosen't create new csv file
def check_csv():
    global player_data
    if os.path.isfile('./Player_Data.csv'):
        player_data = pd.read_csv('Player_Data.csv')
        #print(player_data)
    else:
        player_data.to_csv('Player_Data.csv')
counter = -1

# after game over update the csv file
def update_csv():
    global score_value
    global text
    global counter
    global name_text
    global player_data
    flag = False
    #print(player_data.dtypes)
   # print(f"text Frame {type(text)}")
    
    counter = -1
    for n in player_data['ID']:
        counter +=1
        if str(n)==str(text):
            #print(counter)
            #print(player_data['Score'][counter])
            flag = True
            if score_value > player_data['Score'][counter]:
                player_data.loc[[counter],'Score']=score_value
                player_data.loc[[counter],'Name']=name_text
                #print(player_data)
                player_data['Date'][counter]=pd.to_datetime('today').strftime("%d/%m/%Y")
            print(score_value)
                
    if flag == False:
        new_player =pd.DataFrame({'Rank':[player_data['Rank'].count()+1],'ID':[text],'Name':[name_text],'Score':[score_value],'Date':[pd.to_datetime('today').strftime("%d/%m/%Y")]})
        #print(new_player)  
        player_data = player_data.append(new_player)
        #print(player_data)
        #rank_replace = pd.DataFrame(player_data['Rank'])
        #print(rank_replace.dtypes)
        #print(rank_replace)
    #player_data['Date'] = pd.to_datetime('today').strftime("%d/%m/%Y")
    player_data = player_data.sort_values(by=['Score'],ascending=False)
    #print(player_data)
    #player_data = player_data.drop(['Rank'],axis=1)
    player_data['Rank'] = player_data['Rank'].sort_values().values
    player_data.to_csv('Player_Data.csv',index=None)
    player_data = pd.read_csv('Player_Data.csv')
    #print(player_data)
        #player_data=pd.concat([rank_replace,player_data],ignore_index= True)
      
    print(player_data)
    show_graph()
    #print(player_data.index[player_data['ID'] == text].tolist())

#funtion to plot and save the graph on the disk
def show_graph():
    global player_data
    if (player_data['Rank'].count()<=10):
        locx=1
        locy=10
    elif(player_data['Rank'].count()>10 and player_data['Rank'].count()<=50):
        locx = 5
        locy = 10
    elif(player_data['Rank'].count()>50):
        locx = 10
        locy = 15
    if player_data['Score'][return_rank()-1]<40:
        x= return_rank()-locx
        y= player_data['Score'][return_rank()-1]+locy
    else:
        x= return_rank()+locx
        y= player_data['Score'][return_rank()-1]-locy
    arrow_properties = dict(facecolor="black", width=0.5,headwidth=4, shrink=0.1)
    #plt.plot(player_data['Rank'],player_data['Score'])
    ax = player_data.plot(x='Rank',y='Score')
    plt.scatter(return_rank(),player_data['Score'][return_rank()-1],marker='*',s=70,c='r')
    plt.annotate(f"You are here, \nScore: {player_data['Score'][return_rank()-1]} \nRank: {return_rank()}", xy=(return_rank(),player_data['Score'][return_rank()-1]),xytext=(x,y),arrowprops=arrow_properties)
    ax.locator_params(integer=True)
    plt.xlabel('Rank')
    plt.ylabel('Score')
    plt.title('Balloon Hunt Graph')
    plt.savefig('graph.jpg',dpi=55)
    plt.show()     
        
running = True
sw_no=0
input_cntr=0


#main in game flow
while running:

    #RGB
    pygame.display.update()
    screen.fill((0,0,0))
    #backgorund display
    screen.blit(background,(0,0))
    if(input_cntr==0):
        user_input()
        input_cntr += 1
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False 
            pygame.display.quit()
            pygame.quit()
            sys.exit()
        #keystroke is pressed check weather left or right
        if event.type  == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerX_change = -5
            if event.key == pygame.K_RIGHT:
                playerX_change = 5
            if event.key == pygame.K_SPACE:
                sw_no+=1
                if(sw_no==number_of_swords):
                    sw_no=0
                if sword_state[sw_no] is "ready":
                    #sword_sound= mixer.Sound('laser.wav')
                    #bullet_sound.play()

                    #print(sw_no)
                    swordX[sw_no] = playerX
                    launch_sword(swordX[sw_no],swordY[sw_no],sw_no)

                
        #keystroke is pressed check weather left or right
        if event.type  == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                playerX_change = 0
            if event.key == pygame.K_RIGHT:
                playerX_change = 0
            if event.key == pygame.K_SPACE:
                if sw_no!=(number_of_swords-1):
                    swordY[sw_no+1]=450
    if(damage_value>=100):
        game_over()
        continue    
    #when balloon goes below screen
    for i in range(number_of_balloon):
        enemyY[i] += enemyY_change[i]
        if enemyY[i]>700:
            damage_value +=5
            enemyX[i] = random.randint(0,710)
            enemyY[i] = random.randint(-400,0)
            
        enemy(enemyX[i], enemyY[i],i)
        
        #to detect collision of all swords with all balloon
        for n in range(number_of_swords):
            collision = isCollision(enemyX[i],enemyY[i],swordX[n],swordY[n])
            if collision:
                pop = pygame.mixer.Sound('balloon pop.wav')
                pop.play()
                swordY[n]=450
                swordX[n]=playerX
                sword_state[n]="ready"
                score_value+=1
                enemyY_change[i] +=0.3
                #playerX_change +=0.3
                enemyX[i] = random.randint(0,710)
                enemyY[i] = random.randint(-400,0) 
                #print(score_value)
                

#border for player entity
    playerX += playerX_change 
    if playerX <=0:
        playerX = 0
    elif playerX>=710:
        playerX=710
        
    #print(swordY)
    for n in range(number_of_swords):
        if swordY[n]<=0:
            swordY[n] = 450
            swordX[n] = playerX
            sword_state[n] = 'ready'

        if sword_state[n] is "fire":
            launch_sword(swordX[n],swordY[n],n)
            swordY[n] -=swordY_change[n] 
    #displaying player score and damage while playing game
    player(playerX,playerY)
    show_score(textX,textY)
    show_damage(DtextX, DtextY)
    

